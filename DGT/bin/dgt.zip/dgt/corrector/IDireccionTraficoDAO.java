package dgt.corrector;

import java.util.List;
import java.util.Map;

public interface IDireccionTraficoDAO {
    
    Map<String, String[]> cargarSoluciones() throws DAOException; // De momento String[] porque se supone que siempre es el mismo número de valores
    List<Candidato> cargarCandidatos(String idTest) throws DAOException;
    void guardarPuntajes(List<Candidato> candidatos) throws DAOException;


}
